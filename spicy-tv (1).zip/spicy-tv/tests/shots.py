import sys, json
from playwright.sync_api import sync_playwright

OUT = sys.argv[1]
URL = "file:///home/claude/spicy-tv/site/index.html?demo"
errs = []

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/opt/pw-browsers/chromium", args=["--no-sandbox", "--enable-gpu-rasterization"])
    pg = b.new_page(viewport={"width": 1920, "height": 1080})
    pg.route("**/fonts.googleapis.com/**", lambda r: r.abort())
    pg.on("console", lambda m: errs.append(("console." + m.type, m.text)) if m.type in ("error", "warning") else None)
    pg.on("pageerror", lambda e: errs.append(("pageerror", str(e))))
    pg.goto(URL)
    pg.wait_for_timeout(2500)
    pg.screenshot(path=f"{OUT}/01_start.png")
    pg.wait_for_timeout(9000)
    pg.screenshot(path=f"{OUT}/02_later.png")
    st = pg.evaluate("({cur:cur,lines:lines.length,syn:syn,ui:document.body.className,title:$('t').textContent})")
    print("state after 11s:", st)
    pg.keyboard.press("ArrowRight")
    pg.wait_for_timeout(700)
    pg.screenshot(path=f"{OUT}/03_dock.png")
    print("focused:", pg.evaluate("document.activeElement.id"))
    pg.keyboard.press("ArrowRight")
    print("focused after right:", pg.evaluate("document.activeElement.id"))
    pg.keyboard.press("Enter")  # next
    pg.wait_for_timeout(3500)
    pg.screenshot(path=f"{OUT}/04_next_track.png")
    print("title after next:", pg.evaluate("$('t').textContent"))
    pg.click("#bSet")
    pg.wait_for_timeout(500)
    pg.screenshot(path=f"{OUT}/05_settings.png")
    pg.keyboard.press("ArrowRight")
    pg.keyboard.press("ArrowDown")
    pg.keyboard.press("ArrowRight")
    print("cfg:", pg.evaluate("JSON.stringify({off:cfg.off,sz:cfg.sz})"))
    pg.keyboard.press("Escape")
    pg.wait_for_timeout(8000)
    pg.screenshot(path=f"{OUT}/06_after_close.png")
    pg.keyboard.press("e")
    pg.wait_for_timeout(1200)
    pg.screenshot(path=f"{OUT}/07_cover.png")
    b.close()

print("ERRORS:", json.dumps(errs, indent=1))
