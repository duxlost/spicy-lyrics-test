// Edit these two values, then build/run the project in Tizen Studio.
window.SPICY_CONFIG = {
  // Where you hosted site/index.html (must be https and end with a slash if it is a folder),
  // e.g. "https://yourname.github.io/spicy-tv/". Leave empty to run the built-in demo only.
  appUrl: "",
  // Your Spotify app's Client ID (from developer.spotify.com/dashboard). Not a secret.
  clientId: ""
};
