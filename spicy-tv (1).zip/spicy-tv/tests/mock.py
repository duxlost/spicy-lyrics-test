"""Exercises the REAL Spotify code path (token, polling, LRCLIB, artwork) against mocked network."""
import sys, json, time, io
from PIL import Image, ImageDraw, ImageFilter
from playwright.sync_api import sync_playwright

OUT = sys.argv[1]
URL = "file:///home/claude/spicy-tv/site/index.html"
errs = []

# warm orange/teal artwork so we can judge colour adaptation
img = Image.new("RGB", (640, 640), (255, 122, 24))
d = ImageDraw.Draw(img)
for i in range(7):
    d.ellipse([i * 70 - 60, 80 + (i % 3) * 120, i * 70 + 300, 460 + (i % 3) * 90], fill=[(30, 200, 176), (122, 15, 58), (255, 209, 102)][i % 3])
buf = io.BytesIO(); img.save(buf, "PNG"); ART = buf.getvalue()

lrc = ""
t = 1.0
for s in ["Midnight on the overpass, headlights on the glass", "I keep the radio low", "", "Every red light is a little pause",
          "Where the whole sky turns to gold", "And I don't know where we're going", "But I'm not afraid to go"]:
    lrc += "[%02d:%05.2f]%s\n" % (int(t // 60), t % 60, s)
    t += 3.5 if s else 2.5

start = time.time()
def player(route):
    req = route.request
    if req.method != "GET":
        return route.fulfill(status=204)
    prog = int((time.time() - start) * 1000) + 1000
    route.fulfill(status=200, content_type="application/json", headers={"access-control-allow-origin": "*"}, body=json.dumps({
        "is_playing": True, "progress_ms": prog, "shuffle_state": True, "repeat_state": "off",
        "device": {"name": "Pixel 8"},
        "item": {"id": "t1", "name": "Overpass Gold", "duration_ms": 200000,
                 "artists": [{"name": "Lola Marchetti"}, {"name": "Kiko"}],
                 "album": {"name": "Night Drive", "images": [{"url": "https://i.scdn.co/image/test"}]}}}))

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/opt/pw-browsers/chromium", args=["--no-sandbox"])
    ctx = b.new_context(viewport={"width": 1920, "height": 1080})
    ctx.add_init_script("""
      if(!localStorage.getItem('sp.tok')){localStorage.setItem('sp.tok',JSON.stringify({v:2,a:'x',r:'y',e:Date.now()+1e7}));
      localStorage.setItem('sp.cfg',JSON.stringify({cid:'testcid'}));}""")
    ctx.route("**/api.spotify.com/v1/me/player**", player)
    ctx.route("**/i.scdn.co/**", lambda r: r.fulfill(status=200, body=ART, content_type="image/png", headers={"access-control-allow-origin": "*"}))
    ctx.route("**/lrclib.net/**", lambda r: r.fulfill(status=200, content_type="application/json", headers={"access-control-allow-origin": "*"}, body=json.dumps({"syncedLyrics": lrc})))
    ctx.route("**/fonts.googleapis.com/**", lambda r: r.abort())
    ctx.route("**/sdk.scdn.co/**", lambda r: r.abort())
    pg = ctx.new_page()
    pg.on("pageerror", lambda e: errs.append(("pageerror", str(e))))
    pg.on("console", lambda m: errs.append(("console." + m.type, m.text)) if m.type == "error" and "ERR_FAILED" not in m.text else None)
    pg.goto(URL)
    pg.wait_for_timeout(4500)
    pg.screenshot(path=f"{OUT}/10_real_path.png")
    s = pg.evaluate("({t:$('t').textContent,a:$('a').textContent,dev:$('dev').textContent,cur:cur,lines:lines.length,pos:Math.round(now()),ac:getComputedStyle(root).getPropertyValue('--ac')})")
    print("real path:", s)
    # pause via OK key (UI hidden after wake timeout? force hidden first)
    pg.keyboard.press("Enter"); pg.wait_for_timeout(600)
    print("playing after Enter:", pg.evaluate("st.play"))
    pg.screenshot(path=f"{OUT}/11_paused.png")
    # colour keys (timing) + back
    pg.keyboard.press("Escape")
    ctx2 = b.new_context(viewport={"width": 1920, "height": 1080})
    ctx2.route("**/fonts.googleapis.com/**", lambda r: r.abort())
    pg2 = ctx2.new_page()
    pg2.on("pageerror", lambda e: errs.append(("pageerror2", str(e))))
    pg2.goto(URL + "?cid=abc123")
    pg2.wait_for_timeout(1500)
    pg2.screenshot(path=f"{OUT}/12_welcome.png")
    print("cid persisted:", pg2.evaluate("JSON.parse(localStorage.getItem('sp.cfg')).cid"), "| dialog:", pg2.evaluate("!!dlg()"))
    pg2.keyboard.press("ArrowDown"); pg2.keyboard.press("Enter"); pg2.wait_for_timeout(400)
    print("settings open:", pg2.evaluate("$('dSet').classList.contains('on')"))
    b.close()
print("ERRORS:", json.dumps(errs, indent=1))
