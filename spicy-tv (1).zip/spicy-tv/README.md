# Spicy Player TV

Animated, synced lyrics on your Samsung TV. You pick songs on your phone in Spotify; the TV shows the lyrics, a moving background built from the album art, and playback controls.

```
site/index.html   the player (host this on any https site)
tizen/            the small TV app package (launcher + icon + config)
tests/            headless tests I used (not needed on the TV)
```

## 0. Preview first (no setup)
Open `site/index.html?demo` in Chrome, or install the Tizen app (step 4) and press OK on the launcher. Demo mode plays four fake songs with timed lyrics.

## 1. Which TVs work
The player needs a 2018 or newer Samsung TV (Tizen 4.0+). Look at the model code: after the screen size comes a letter for the year.
`UE55**N**U8000` = 2018 ✅  `R` 2019 ✅  `T` 2020 ✅  `A/B/C/D/E` 2021-2025 ✅  `M` (2017) or earlier ❌ (the TV browser is too old; the page shows a message).

## 2. Spotify setup (once)
1. Go to developer.spotify.com/dashboard → Create app. Tick **Web API** (and Web Playback SDK if you want to try the experimental option).
2. Add the **Redirect URI**: exactly the https address of your hosted player (step 3), e.g. `https://yourname.github.io/spicy-tv/`.
3. Copy the app's **Client ID**. In the app's *User management*, add the email of the Spotify account you will use (apps in development mode only work for listed users). Spotify has been tightening developer rules, so check the dashboard for any current requirements.

## 3. Host the player (free)
GitHub Pages: create a public repo (e.g. `spicy-tv`), upload `site/index.html`, then Settings → Pages → deploy from the main branch. Your address is `https://<you>.github.io/spicy-tv/`.

## 4. Install on the TV
1. TV: Apps → press `1 2 3 4 5` on the remote → Developer mode **On**, enter your computer's IP, reboot the TV.
2. Computer: install **Tizen Studio** with the *TV Extensions*. Create a Samsung certificate in Certificate Manager (Samsung account; it must include your TV).
3. Edit `tizen/config.js`: set `appUrl` (your https address) and `clientId`.
4. Tizen Studio → File → Import → Tizen project → pick the `tizen` folder. Device Manager → connect your TV's IP. Right-click the project → Run As → Tizen Web Application.
5. First launch: choose **Connect Spotify** and log in on the TV. After that it opens straight into the player.

**Plan B (nothing to install):** open the same https address in the TV's built-in Internet browser. It works the same, just with the browser frame around it.

## 5. Daily use
Open Spotify on your phone, play any song, and the TV follows within a few seconds. (The audio comes from wherever you play it: your phone, a speaker, a soundbar.)

## Remote
| Key | Action |
|---|---|
| OK | Play/pause (shows controls first if hidden) |
| ◀ ▶ | Move between buttons |
| Back | Hide controls, then leave cover view, then exit |
| ⏪ ⏩ | Seek −10 s / +10 s |
| ⏮ ⏭ | Previous / next |
| Red | Resync • Green: cover view • Yellow / Blue: lyrics −0.1 s / +0.1 s |

Tip: if the lyrics feel early or late, use Yellow/Blue, or Settings → Lyrics timing.

## Known limits
- Audio **on the TV itself** is experimental (Settings → Play audio on this TV). Spotify's web player is often not supported by TV browsers. If it fails, play from your phone, or use Spotify's own TV app (not at the same time as this one).
- Seeking, play/pause and skip need Spotify Premium. Showing lyrics does not.
- Lyrics come from LRCLIB (community-made). Some songs are missing or not timed.
- Not tested on a physical TV. Everything was verified in a 1080p desktop browser with a mocked Spotify account.
